#pragma once
#include "cCubeNode.h"
class cRightArm :
    public cCubeNode
{
public:
	cRightArm();
	~cRightArm();

public:
	virtual void Setup() override;
};

