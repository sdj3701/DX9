#pragma once
#include "cCubeNode.h"
class cHead :
    public cCubeNode
{
public:
	cHead();
	~cHead();

public:
	virtual void Setup() override;
};

