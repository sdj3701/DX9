#pragma once
#include "cCubeNode.h"
class cLeftLeg :
    public cCubeNode
{
public:
	cLeftLeg();
	~cLeftLeg();

public:
	virtual void Setup() override;
};

