#pragma once
#include "cCubeNode.h"
class cLeftArm :
    public cCubeNode
{
public:
	cLeftArm();
	~cLeftArm();

public:
	virtual void Setup() override;
};

