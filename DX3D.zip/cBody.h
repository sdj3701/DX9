#pragma once
#include "cCubeNode.h"
class cBody :
    public cCubeNode
{
public:
	cBody();
	~cBody();

public:
	virtual void Setup() override;

};

