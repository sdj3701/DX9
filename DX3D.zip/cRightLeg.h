#pragma once
#include "cCubeNode.h"
class cRightLeg :
    public cCubeNode
{
public:
	cRightLeg();
	~cRightLeg();

public:
	virtual void Setup() override;
};

